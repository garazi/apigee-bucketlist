/** Automatically generated file. DO NOT MODIFY */
package com.phonegap.sample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}